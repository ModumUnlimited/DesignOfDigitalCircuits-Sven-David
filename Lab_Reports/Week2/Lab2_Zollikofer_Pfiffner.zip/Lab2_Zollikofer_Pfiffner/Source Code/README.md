# Lab 2

This is our Lab 2 submission. In this folder you will find:

## Exercise 1 - Decoder

The decoder takes a two bit input signal (fully binary encoded) and maps it onto a one-hot encoded 4 bit bus. The switches R2 and T1 set the input and the leds V19-V16 show which line is active.

## Exercise 2 - Multiplexer

The multiplexer has four inputs which can get connected to an output. Depending on what binary pattern can be found at the selection bus it maps the corresponding input to the output.